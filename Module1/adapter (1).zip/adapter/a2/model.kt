package com.highway.module3

class model(val img:Int,val name:String,val position:String,val joiningdate:String) {

}