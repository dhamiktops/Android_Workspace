package com.highway.module3

class model(val img:Int) {

}