package com.highway.module3

class model(val name:String,val surname:String,val email:String) {

}